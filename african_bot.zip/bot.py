import json, os, time, shutil
from yt_dlp import YoutubeDL
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

# --- Configuration & Fichiers ---
os.environ["TZ"] = "UTC"

try:
    with open("config.json") as f:
        config = json.load(f)
except Exception:
    print("Erreur : config.json manquant !")
    exit()

TOKEN = config["TOKEN"]
ADMIN_ID = int(config["ADMIN_ID"]) # Ton ID Telegram
RESULTS_PER_PAGE = 5
NODE_PATH = shutil.which("node") or "/data/data/com.termux/files/usr/bin/node"
USER_FILE = "users.json"

# --- Gestion des Utilisateurs (DB Light) ---
def save_user(user_id):
    users = []
    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as f: users = json.load(f)
    if user_id not in users:
        users.append(user_id)
        with open(USER_FILE, "w") as f: json.dump(users, f)

def get_stats():
    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as f: return len(json.load(f))
    return 0

# --- Menus ---

def main_menu(user_id):
    keyboard = [
        [InlineKeyboardButton("🎵 Rechercher une musique", callback_data="start_search")],
        [InlineKeyboardButton("ℹ️ Infos & Contact", callback_data="show_infos")],
        [InlineKeyboardButton("💬 Support Direct", url="https://t.me")]
    ]
    # Ajoute le bouton Admin si c'est toi
    if user_id == ADMIN_ID:
        keyboard.append([InlineKeyboardButton("🔐 Espace Admin", callback_data="admin_panel")])
    
    return InlineKeyboardMarkup(keyboard)

def admin_menu():
    keyboard = [
        [InlineKeyboardButton("📊 Statistiques", callback_data="admin_stats")],
        [InlineKeyboardButton("📢 Diffusion (Broadcast)", callback_data="admin_broadcast")],
        [InlineKeyboardButton("🔙 Retour", callback_data="main_menu")]
    ]
    return InlineKeyboardMarkup(keyboard)

def back_btn():
    return InlineKeyboardButton("🔙 Retour au Menu", callback_data="main_menu")

# --- Logique YouTube ---

def get_ydl_opts(is_search=False, file_id=None):
    opts = {"js_runtimes": {"node": {"path": NODE_PATH}}, "quiet": True, "no_warnings": True}
    if is_search:
        opts["skip_download"] = True
    else:
        opts.update({
            "format": "best", "outtmpl": f"dl_{file_id}.%(ext)s",
            "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "64"}],
            "keepvideo": True,
        })
    return opts

def search_youtube(query):
    with YoutubeDL(get_ydl_opts(is_search=True)) as ydl:
        info = ydl.extract_info(f"ytsearch20:{query}", download=False)["entries"]
    return [(i["title"], i["webpage_url"]) for i in info]

def build_results_menu(results, page=0):
    start, end = page * RESULTS_PER_PAGE, (page + 1) * RESULTS_PER_PAGE
    buttons = [[InlineKeyboardButton(t[:40], callback_data=u)] for t, u in results[start:end]]
    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️", callback_data=f"p_{page-1}"))
    if end < len(results): nav.append(InlineKeyboardButton("➡️", callback_data=f"p_{page+1}"))
    if nav: buttons.append(nav)
    buttons.append([back_btn()])
    return InlineKeyboardMarkup(buttons)

# --- Handlers ---

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    save_user(user_id)
    msg = "🔥 **Mister-v-vibe Bot**\n\nBienvenue dans ton espace musical."
    if update.message:
        await update.message.reply_text(msg, reply_markup=main_menu(user_id), parse_mode="Markdown")
    else:
        await update.callback_query.edit_message_text(msg, reply_markup=main_menu(user_id), parse_mode="Markdown")

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Vérifie si l'admin est en train d'écrire un broadcast
    if context.user_data.get("admin_state") == "broadcast" and update.effective_user.id == ADMIN_ID:
        users = []
        if os.path.exists(USER_FILE):
            with open(USER_FILE, "r") as f: users = json.load(f)
        count = 0
        for uid in users:
            try:
                await context.bot.send_message(uid, f"📢 **MESSAGE DE L'ADMIN**\n\n{update.message.text}", parse_mode="Markdown")
                count += 1
            except: pass
        await update.message.reply_text(f"✅ Message envoyé à {count} utilisateurs.")
        context.user_data["admin_state"] = None
        return

    # Sinon c'est une recherche
    try:
        wait = await update.message.reply_text("🔍 Recherche...")
        results = search_youtube(update.message.text)
        context.user_data["results"] = results
        await wait.delete()
        await update.message.reply_text(f"🎶 Résultats pour : *{update.message.text}*", reply_markup=build_results_menu(results, 0), parse_mode="Markdown")
    except Exception as e:
        await update.message.reply_text(f"❌ Erreur : {e}")

async def button_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    data = query.data
    await query.answer()

    if data == "main_menu":
        await start(update, context)
    
    elif data == "admin_panel" and user_id == ADMIN_ID:
        await query.edit_message_text("🔐 **PANNEAU ADMINISTRATEUR**", reply_markup=admin_menu(), parse_mode="Markdown")

    elif data == "admin_stats" and user_id == ADMIN_ID:
        await query.edit_message_text(f"📊 **Statistiques**\n\nUtilisateurs inscrits : {get_stats()}", reply_markup=admin_menu(), parse_mode="Markdown")

    elif data == "admin_broadcast" and user_id == ADMIN_ID:
        context.user_data["admin_state"] = "broadcast"
        await query.edit_message_text("📢 Écris maintenant le message que tu veux envoyer à TOUS les utilisateurs :", reply_markup=InlineKeyboardMarkup([[back_btn()]]))

    elif data == "show_infos":
        info = f"📌 **INFOS**\n👤 Admin : Mister-v-vibe\n✈️ Telegram : @DLGOFFICIEL\n👥 Users : {get_stats()}"
        await query.edit_message_text(info, reply_markup=InlineKeyboardMarkup([[back_btn()]]), parse_mode="Markdown")

    elif data == "start_search":
        await query.edit_message_text("🎹 Envoie le nom d'une chanson...")

    elif data.startswith("p_"):
        page = int(data.split("_")[1])
        await query.edit_message_reply_markup(build_results_menu(context.user_data.get("results", []), page))

    elif data.startswith("http"):
        msg = await query.message.reply_text("Téléchargement... ⏳")
        file_id = str(int(time.time()))
        try:
            with YoutubeDL(get_ydl_opts(file_id=file_id)) as ydl:
                info = ydl.extract_info(data, download=True)
                v_file = ydl.prepare_filename(info)
                a_file = f"{v_file.rsplit('.', 1)[0]}.mp3"
            if os.path.exists(a_file):
                with open(a_file, "rb") as f: await context.bot.send_audio(query.message.chat_id, f, title=info.get("title"))
                os.remove(a_file)
            if os.path.exists(v_file):
                with open(v_file, "rb") as f: await context.bot.send_video(query.message.chat_id, f, caption=info.get("title"))
                os.remove(v_file)
        except Exception as e: await query.message.reply_text(f"❌ Erreur : {e}")
        finally:
            try: await msg.delete()
            except: pass

def main():
    app = ApplicationBuilder().token(TOKEN).connect_timeout(60).read_timeout(60).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_click))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    print("Bot Mister-v-vibe avec Espace Admin activé !")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__": main()

